#!/usr/bin/perl
#
use strict;
use warnings;

open FILE, 'sample.fastq';
open OUT, '>sample_fasta.txt';

my $line = 0; #set local scalar flag to 0
while (<FILE>) { #read each line of data file
    if ($line) {
        $line = 0;
        print OUT; #print line is 0 print to OUT file
    }
    if (/^@/) { #if line starts with @ character set flag to 1
        $line = 1;
        print OUT;  #print line with @ and following line to OUT file
    }
} #program will print lines labeled as '1' and and the line following.

close(FILE);
close(OUT);
