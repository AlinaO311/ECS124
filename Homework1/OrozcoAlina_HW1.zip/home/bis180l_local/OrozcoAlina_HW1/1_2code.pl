#!/usr/bin/perl

print "When in double quotes:\n";
print "Use \\ to output \\\n";
print "Use \\t to output tabs\n";

=commentstart
When in double quotes:
Use \ to output \
Use \t to output tabs
=commentend
