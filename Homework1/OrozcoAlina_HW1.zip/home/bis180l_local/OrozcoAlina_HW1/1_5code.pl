#!/usr/bin/perl
#
$P = 'VRNrIAEelslrrFMVALILdlKrTPgNKPriaemICDIDtYIvEa';
print "$P \n";
$P =~ tr/A-Za-z/a-zA-Z/;
print "$P \n";

=commentstart
VRNrIAEelslrrFMVALILdlKrTPgNKPriaemICDIDtYIvEa ##STDIN
vrnRiaeELSLRRfmvalilDLkRtpGnkpRIAEMicdidTyiVeA ##STDOUt
=commentend
