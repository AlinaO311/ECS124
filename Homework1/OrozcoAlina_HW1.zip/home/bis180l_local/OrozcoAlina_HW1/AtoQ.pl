#!/usr/bin/perl

open IN, 'sample_fasta.txt'; #open file to be read
open OUT, '>sample_fastq.txt'; #open file to be written to

$newline;

while($newline=<IN>) #while reading newline from file IN
{
  $newline=~ tr/>/@/; #replace > symbol in newline with @
	print OUT $newline; #print this new line to new OUT file
  $copy1=$newline; #let copy1 be the next newline
	$newline=<IN>; #read next line
	$copy2=$newline; #let copy2 be the newline read on the previous line
	print OUT $newline; # copy this line to OUT file
  $copy1=~ tr/@/+/; #in line copy1 replace @ symbol with + character
  print OUT $copy1; # print copy1 to OUT file
  $copy2=~ tr/ATGC/X/; # replace all characters in copied line 2 with X
	print OUT $copy2; #print  copy2 to OUT file
}

close(IN);
close(OUT);
